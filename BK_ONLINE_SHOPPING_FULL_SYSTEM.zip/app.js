(() => {
const $ = id => document.getElementById(id);
const money = (amount, currency) => (currency === "USD" ? "$" : "₨") + Number(amount || 0).toLocaleString(undefined,{maximumFractionDigits:2});
let db=null, user=null, profile=null, products=[], cart=[], currency="PKR", authMode="login";
const say=(id,msg)=>{const el=$(id);if(el)el.textContent=msg};
const safe=(s)=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const open=id=>$(id).hidden=false, close=id=>$(id).hidden=true;
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>close(b.dataset.close)));
$("accountBtn").onclick=()=>{authMode=user?"login":"login";setAuthMode("login");open("authModal")};
$("cartBtn").onclick=()=>{renderCart();open("cartModal")};
$("currencyBtn").onclick=()=>{currency=currency==="PKR"?"USD":"PKR";$("currencyBtn").textContent=currency==="PKR"?"PKR ₨":"USD $";renderProducts()};
$("loginTab").onclick=()=>setAuthMode("login");$("signupTab").onclick=()=>setAuthMode("signup");
function setAuthMode(mode){authMode=mode;$("loginTab").classList.toggle("active",mode==="login");$("signupTab").classList.toggle("active",mode==="signup");$("nameLabel").hidden=mode!=="signup";$("fullName").required=mode==="signup";$("authTitle").textContent=mode==="login"?"Welcome back":"Create your account";$("authSubmit").textContent=mode==="login"?"Sign in":"Create account";$("forgotBtn").hidden=mode!=="login";say("authMessage","")}
function init(){
 if(!window.supabase||!window.BK_SUPABASE_URL||!window.BK_SUPABASE_PUBLISHABLE_KEY){say("authMessage","Supabase configuration missing. Check supabase-config.js.");return}
 db=window.supabase.createClient(window.BK_SUPABASE_URL,window.BK_SUPABASE_PUBLISHABLE_KEY);
 db.auth.onAuthStateChange((_event,session)=>{user=session?.user||null;setTimeout(loadProfile,0)});
 loadProducts();db.auth.getSession().then(({data})=>{user=data.session?.user||null;loadProfile()});
}
async function loadProfile(){
 if(!db)return;
 if(!user){profile=null;$("accountBtn").textContent="Sign in";$("dashboard").hidden=true;renderOrders([]);return}
 const {data,error}=await db.from("profiles").select("*").eq("id",user.id).maybeSingle();
 profile=data||{id:user.id,full_name:user.user_metadata?.full_name||"",role:"customer"};
 $("accountBtn").textContent="My account";$("dashboard").hidden=false;
 $("dashboardTitle").textContent=profile.role==="admin"?"Admin dashboard":profile.role==="seller"?"Seller dashboard":"Customer dashboard";
 $("userRole").textContent=`Signed in as ${user.email} • ${profile.role}`;
 renderDashboard();loadOrders();
}
async function loadProducts(){
 if(!db){$("productGrid").innerHTML='<div class="empty">Supabase is not configured yet. Add the SQL schema and check your project settings.</div>';return}
 $("productGrid").innerHTML='<div class="empty">Loading products...</div>';
 const {data,error}=await db.from("products").select("id,name,category,description,price,currency,image_url,seller_id").eq("is_active",true).order("created_at",{ascending:false});
 if(error){$("productGrid").innerHTML=`<div class="empty">Could not load products: ${safe(error.message)}. Run schema.sql in Supabase first.</div>`;return}
 products=data||[];renderProducts();
}
function renderProducts(){
 const q=$("searchInput").value.toLowerCase(),cat=$("categoryFilter").value;
 const list=products.filter(p=>(!cat||p.category===cat)&&(`${p.name} ${p.description||""}`.toLowerCase().includes(q)));
 $("productGrid").innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image">${p.image_url?`<img src="${safe(p.image_url)}" alt="${safe(p.name)}" loading="lazy" onerror="this.remove()">`:"✦"}</div><div class="product-info"><small>${safe(p.category||"Other")}</small><h3>${safe(p.name)}</h3><p>${safe((p.description||"").slice(0,90))}</p><div class="product-bottom"><span class="price">${money(p.price,currency)}</span><button class="add-btn" data-add="${p.id}">Add to cart</button></div></div></article>`).join(""):'<div class="empty">No products found yet. Seller listings will appear here.</div>';
 document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>{const p=products.find(x=>x.id===b.dataset.add);if(p){cart.push(p);$("cartCount").textContent=cart.length;b.textContent="Added";setTimeout(()=>b.textContent="Add to cart",900)}});
}
$("searchInput").addEventListener("input",renderProducts);$("categoryFilter").addEventListener("change",renderProducts);$("refreshBtn").onclick=loadProducts;
function renderCart(){
 $("cartItems").innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-row"><span>${safe(p.name)}<br><small>${money(p.price,p.currency)}</small></span><button class="small-btn danger" data-remove="${i}">Remove</button></div>`).join(""):'<div class="empty">Your cart is empty.</div>';
 const total=cart.reduce((s,p)=>s+Number(p.price),0);$("cartTotal").textContent=money(total,cart[0]?.currency||currency);$("cartCount").textContent=cart.length;
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart.splice(Number(b.dataset.remove),1);renderCart()});
}
$("authForm").onsubmit=async e=>{
 e.preventDefault();if(!db)return say("authMessage","Supabase configuration missing.");
 const email=$("email").value.trim(),password=$("password").value;
 $("authSubmit").disabled=true;say("authMessage","Please wait...");
 try{
  if(authMode==="signup"){
   const {data,error}=await db.auth.signUp({email,password,options:{data:{full_name:$("fullName").value.trim()}}});if(error)throw error;
   say("authMessage",data.session?"Account created. You are signed in.":"Account created request. Check your email for the confirmation link.");
  }else{const {error}=await db.auth.signInWithPassword({email,password});if(error)throw error;say("authMessage","Signed in successfully.");close("authModal")}
 }catch(err){say("authMessage",err.message||"Authentication failed.")}finally{$("authSubmit").disabled=false}
};
$("forgotBtn").onclick=async()=>{const email=$("email").value.trim();if(!email)return say("authMessage","Enter your email first.");const {error}=await db.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});say("authMessage",error?error.message:"If the account exists, a reset email has been sent.")};
$("signOutBtn").onclick=async()=>{await db.auth.signOut();profile=null;user=null;$("dashboard").hidden=true;$("accountBtn").textContent="Sign in";say("ordersList","Sign in to view orders.")};
$("checkoutBtn").onclick=async()=>{
 if(!user){close("cartModal");open("authModal");return say("authMessage","Please sign in before placing an order.")}
 if(!cart.length)return say("cartMessage","Your cart is empty.");
 if(cart.some(p=>p.currency!==cart[0].currency))return say("cartMessage","Please order products in the same currency in one checkout.");
 $("checkoutBtn").disabled=true;say("cartMessage","Placing your order...");
 try{
  const total=cart.reduce((s,p)=>s+Number(p.price),0);
  const {data:order,error}=await db.from("orders").insert({customer_id:user.id,total_amount:total,currency:cart[0].currency,status:"pending"}).select().single();if(error)throw error;
  const rows=cart.map(p=>({order_id:order.id,product_id:p.id,seller_id:p.seller_id,product_name:p.name,quantity:1,unit_price:p.price,currency:p.currency}));
  const {error:itemsError}=await db.from("order_items").insert(rows);if(itemsError)throw itemsError;
  cart=[];renderCart();say("cartMessage","Order placed. Payment is not collected by this demo; contact the seller to arrange payment.");loadOrders();loadProducts();
 }catch(err){say("cartMessage",err.message||"Could not place order.")}finally{$("checkoutBtn").disabled=false}
};
function renderOrders(rows){$("ordersList").innerHTML=rows.length?rows.map(o=>`<div class="order-card"><div><strong>Order #${safe(o.id.slice(0,8))}</strong><small>${new Date(o.created_at).toLocaleString()} • ${money(o.total_amount,o.currency)}</small></div><span class="status-pill">${safe(o.status)}</span></div>`).join(""):'<div class="empty">No orders to show.</div>'}
async function loadOrders(){if(!user)return;const {data,error}=await db.from("orders").select("*").order("created_at",{ascending:false});if(!error)renderOrders(data||[])}
function renderDashboard(){
 const role=profile?.role||"customer",isAdmin=role==="admin",isSeller=role==="seller"||isAdmin;
 $("dashboardContent").innerHTML=`<div class="dash-grid"><div class="stat"><small>Account role</small><strong>${safe(role)}</strong></div><div class="stat"><small>Cart items</small><strong>${cart.length}</strong></div><div class="stat"><small>Account</small><strong>Active</strong></div></div>
 <div class="dash-actions">${isSeller?'<button id="addProductBtn" class="primary">＋ Add product</button>':''}${isAdmin?'<button id="adminRefreshBtn" class="outline">Refresh admin data</button>':''}</div>
 <div id="sellerProducts"></div><div id="adminOrders"></div>
 ${role==="customer"?'<div class="empty">Customer account is active. Use the shop above to add products to your cart and place orders.</div>':''}
 ${role==="pending_seller"?'<div class="empty">Your seller access is waiting for administrator approval.</div>':''}`;
 if(isSeller){$("addProductBtn").onclick=()=>showProductForm();loadSellerProducts()}
 if(isAdmin){$("adminRefreshBtn").onclick=loadAdminData;loadAdminData()}
}
async function loadSellerProducts(){
 const {data,error}=await db.from("products").select("*").order("created_at",{ascending:false});
 if(error)return $("sellerProducts").innerHTML=`<p class="message">${safe(error.message)}</p>`;
 const own=data.filter(p=>profile.role==="admin"||p.seller_id===user.id);
 $("sellerProducts").innerHTML=`<h3>Your product listings</h3><div class="table-wrap"><table><thead><tr><th>Product</th><th>Price</th><th>Status</th><th>Action</th></tr></thead><tbody>${own.map(p=>`<tr><td>${safe(p.name)}</td><td>${money(p.price,p.currency)}</td><td>${p.is_active?"Live":"Hidden"}</td><td><button class="small-btn" data-edit="${p.id}">Edit</button> <button class="small-btn danger" data-delete="${p.id}">Delete</button></td></tr>`).join("")||'<tr><td colspan="4">No products yet.</td></tr>'}</tbody></table></div>`;
 document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>showProductForm(own.find(p=>p.id===b.dataset.edit)));
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("Delete this product?"))return;const {error}=await db.from("products").delete().eq("id",b.dataset.delete);if(error)alert(error.message);else loadSellerProducts(),loadProducts()});
}
function showProductForm(p=null){
 $("productForm").reset();$("productId").value=p?.id||"";$("productName").value=p?.name||"";$("productCategory").value=p?.category||"Electronics";$("productDescription").value=p?.description||"";$("productPrice").value=p?.price||"";$("productCurrency").value=p?.currency||"PKR";$("productImage").value=p?.image_url||"";$("productModalTitle").textContent=p?"Edit product":"Add product";say("productMessage","");open("productModal")
}
$("productForm").onsubmit=async e=>{
 e.preventDefault();const id=$("productId").value;
 const row={name:$("productName").value.trim(),category:$("productCategory").value,description:$("productDescription").value.trim(),price:Number($("productPrice").value),currency:$("productCurrency").value,image_url:$("productImage").value.trim()||null,seller_id:user.id,is_active:true};
 const result=id?await db.from("products").update(row).eq("id",id):await db.from("products").insert(row);
 if(result.error)return say("productMessage",result.error.message);
 close("productModal");loadProducts();loadSellerProducts();
};
async function loadAdminData(){
 const [{data:orders,error:e1},{data:profiles,error:e2}] = await Promise.all([db.from("orders").select("*").order("created_at",{ascending:false}),db.from("profiles").select("id,full_name,role,created_at").order("created_at",{ascending:false})]);
 if(e1||e2){$("adminOrders").innerHTML=`<p class="message">${safe((e1||e2).message)}</p>`;return}
 $("adminOrders").innerHTML=`<h3>All orders</h3><div class="table-wrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Update</th></tr></thead><tbody>${orders.map(o=>`<tr><td>${o.id.slice(0,8)}</td><td>${o.customer_id.slice(0,8)}</td><td>${money(o.total_amount,o.currency)}</td><td>${safe(o.status)}</td><td><select data-status="${o.id}"><option ${o.status==="pending"?"selected":""}>pending</option><option ${o.status==="processing"?"selected":""}>processing</option><option ${o.status==="shipped"?"selected":""}>shipped</option><option ${o.status==="completed"?"selected":""}>completed</option><option ${o.status==="cancelled"?"selected":""}>cancelled</option></select></td></tr>`).join("")||'<tr><td colspan="5">No orders.</td></tr>'}</tbody></table></div><h3 style="margin-top:25px">Accounts & seller approvals</h3><div class="table-wrap"><table><thead><tr><th>Name</th><th>Role</th><th>Change role</th></tr></thead><tbody>${profiles.map(p=>`<tr><td>${safe(p.full_name||p.id.slice(0,8))}</td><td>${safe(p.role)}</td><td><select data-role="${p.id}"><option ${p.role==="customer"?"selected":""}>customer</option><option ${p.role==="pending_seller"?"selected":""}>pending_seller</option><option ${p.role==="seller"?"selected":""}>seller</option><option ${p.role==="admin"?"selected":""}>admin</option></select></td></tr>`).join("")}</tbody></table></div><p class="tiny">Role changes are enforced by database permissions. Only an existing admin can change roles.</p>`;
 document.querySelectorAll("[data-status]").forEach(s=>s.onchange=async()=>{const {error}=await db.from("orders").update({status:s.value}).eq("id",s.dataset.status);if(error)alert(error.message)});
 document.querySelectorAll("[data-role]").forEach(s=>s.onchange=async()=>{const {error}=await db.from("profiles").update({role:s.value}).eq("id",s.dataset.role);if(error)alert(error.message);else loadProfile()});
}
$("sellerAccessBtn").onclick=async()=>{if(!user){open("authModal");return say("authMessage","Create an account or sign in first.")}if(profile.role==="seller"||profile.role==="admin"){document.getElementById("dashboard").scrollIntoView();return}const {error}=await db.from("profiles").update({role:"pending_seller"}).eq("id",user.id);if(error)alert(error.message);else{alert("Seller access request submitted. The administrator must approve it.");loadProfile()}};
init();
})();