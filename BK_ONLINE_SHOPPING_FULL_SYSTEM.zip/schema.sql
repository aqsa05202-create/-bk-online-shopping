-- B_K ONLINE SHOPPING database schema
-- Run this whole file in Supabase Dashboard > SQL Editor > New query.
-- Uses a publishable key in the browser and Row Level Security for data protection.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'customer' check (role in ('customer','pending_seller','seller','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin'); $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, full_name, role)
  values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_bk on auth.users;
create trigger on_auth_user_created_bk
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  category text not null default 'Other',
  description text,
  price numeric(12,2) not null check(price > 0),
  currency text not null default 'PKR' check(currency in ('PKR','USD')),
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  total_amount numeric(12,2) not null check(total_amount >= 0),
  currency text not null check(currency in ('PKR','USD')),
  status text not null default 'pending' check(status in ('pending','processing','shipped','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  seller_id uuid not null references public.profiles(id),
  product_name text not null,
  quantity integer not null default 1 check(quantity > 0),
  unit_price numeric(12,2) not null check(unit_price > 0),
  currency text not null check(currency in ('PKR','USD'))
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

drop policy if exists "profile read self or admin" on public.profiles;
create policy "profile read self or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "profile update self limited" on public.profiles;
create policy "profile update self limited" on public.profiles for update to authenticated
using (id = auth.uid() or public.is_admin())
with check (
  public.is_admin()
  or (id = auth.uid() and role in ('customer','pending_seller'))
);

drop policy if exists "public read active products" on public.products;
create policy "public read active products" on public.products for select to anon, authenticated
using (is_active = true or seller_id = auth.uid() or public.is_admin());

drop policy if exists "seller insert own products" on public.products;
create policy "seller insert own products" on public.products for insert to authenticated
with check (seller_id = auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('seller','admin')));

drop policy if exists "seller update own products" on public.products;
create policy "seller update own products" on public.products for update to authenticated
using (seller_id = auth.uid() or public.is_admin())
with check (seller_id = auth.uid() or public.is_admin());

drop policy if exists "seller delete own products" on public.products;
create policy "seller delete own products" on public.products for delete to authenticated
using (seller_id = auth.uid() or public.is_admin());

drop policy if exists "customer create own order" on public.orders;
create policy "customer create own order" on public.orders for insert to authenticated
with check (customer_id = auth.uid() and status = 'pending');

drop policy if exists "customer seller admin read orders" on public.orders;
create policy "customer seller admin read orders" on public.orders for select to authenticated
using (
 customer_id = auth.uid()
 or public.is_admin()
 or exists(select 1 from public.order_items oi where oi.order_id=orders.id and oi.seller_id=auth.uid())
);

drop policy if exists "admin update orders" on public.orders;
create policy "admin update orders" on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "order owner add items" on public.order_items;
create policy "order owner add items" on public.order_items for insert to authenticated
with check (
 exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid())
 and exists(select 1 from public.products p where p.id=product_id and p.seller_id=seller_id and p.is_active=true)
);

drop policy if exists "customer seller admin read items" on public.order_items;
create policy "customer seller admin read items" on public.order_items for select to authenticated
using (
 exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid())
 or seller_id=auth.uid()
 or public.is_admin()
);

grant usage on schema public to anon, authenticated;
grant select on public.products to anon, authenticated;
grant select, insert, update, delete on public.products to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update on public.orders to authenticated;
grant select, insert on public.order_items to authenticated;

-- IMPORTANT: After creating your first account, promote that account to admin
-- from SQL Editor. Replace the email with your own account email:
-- update public.profiles p set role='admin'
-- from auth.users u where p.id=u.id and u.email='YOUR_EMAIL_HERE';
-- Never place a service_role/secret key in website files.
