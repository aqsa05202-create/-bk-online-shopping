// Browser-safe project URL and publishable key only.
// Never put a Supabase secret/service_role key in this file.
window.BK_SUPABASE_URL = "https://xkbdxorssrmuxbrbfljd.supabase.co";
window.BK_SUPABASE_PUBLISHABLE_KEY = "sb_publishable_qP3N0WKucQgJm_VKbZAjQQ_8CjzJ_9J";
