/* Add only your Supabase Project URL and publishable/anon key here.
   NEVER put a service_role or secret key in website files. */
window.BK_SUPABASE_URL = 'PASTE_YOUR_PROJECT_URL_HERE';
window.BK_SUPABASE_ANON_KEY = 'PASTE_YOUR_PUBLISHABLE_OR_ANON_KEY_HERE';
