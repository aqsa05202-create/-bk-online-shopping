(() => {
 const $ = id => document.getElementById(id);
 const ready = window.supabase && window.BK_SUPABASE_URL && window.BK_SUPABASE_ANON_KEY && !window.BK_SUPABASE_URL.includes('PASTE_') && !window.BK_SUPABASE_ANON_KEY.includes('PASTE_');
 let client = null, mode = 'signup';
 if (ready) { client = window.supabase.createClient(window.BK_SUPABASE_URL, window.BK_SUPABASE_ANON_KEY); $('configNotice').hidden = true; }
 const say = (msg, bad=false) => { $('message').textContent = msg; $('message').className = bad ? 'error' : 'info'; };
 const setMode = next => { mode=next; document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode)); $('confirmWrap').hidden=mode!=='signup'; $('submitBtn').textContent=mode==='signup'?'Create account':'Sign in'; $('password').autocomplete=mode==='signup'?'new-password':'current-password'; say(''); };
 document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
 $('authForm').addEventListener('submit', async e => { e.preventDefault(); if(!client){say('Setup required: add your Supabase URL and public key first.',true);return;} const email=$('email').value.trim(), password=$('password').value; $('submitBtn').disabled=true;
 try { if(mode==='signup'){ if(password!==$('confirmPassword').value) throw new Error('Passwords do not match.'); const {data,error}=await client.auth.signUp({email,password,options:{emailRedirectTo:location.origin+location.pathname}}); if(error) throw error; say(data.session?'Account created and signed in.':'Account created. Check your email for the confirmation link.'); } else { const {error}=await client.auth.signInWithPassword({email,password}); if(error) throw error; say('Signed in successfully.'); await refresh(); } } catch(err){say(err.message||'Something went wrong.',true);} finally{$('submitBtn').disabled=false;} });
 $('forgotBtn').addEventListener('click',async()=>{if(!client){say('Add Supabase URL and public key first.',true);return;}const email=$('email').value.trim();if(!email){say('Enter your email address first.',true);return;}try{const {error}=await client.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});if(error)throw error;say('If this email is registered, a password reset link will be sent.');}catch(e){say(e.message,true);}});
 async function refresh(){if(!client)return;const {data}=await client.auth.getSession();const user=data.session?.user;$('accountArea').hidden=!user;$('authArea').hidden=!!user;if(user)$('userEmail').textContent=user.email||'Signed-in customer';}
 $('signOutBtn').addEventListener('click',async()=>{if(!client)return;const {error}=await client.auth.signOut();if(error)say(error.message,true);else{say('Signed out.');await refresh();}});
 if(client){client.auth.onAuthStateChange(()=>refresh());refresh();}
})();
