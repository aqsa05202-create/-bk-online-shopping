(() => {
  const $ = (id) => document.getElementById(id);
  const status = (message, isError = false) => {
    $("status").textContent = message;
    $("status").style.color = isError ? "#b42318" : "#1769aa";
  };

  let client;
  try {
    if (!window.supabase || !window.BK_SUPABASE_URL || !window.BK_SUPABASE_ANON_KEY) {
      throw new Error("Supabase settings load nahi huin. supabase-config.js check karein.");
    }
    client = window.supabase.createClient(window.BK_SUPABASE_URL, window.BK_SUPABASE_ANON_KEY);
  } catch (error) {
    status(error.message, true);
    return;
  }

  const signupForm = $("signup-form");
  const loginForm = $("login-form");
  const accountArea = $("account-area");

  function showTab(tab) {
    const signup = tab === "signup";
    signupForm.hidden = !signup;
    loginForm.hidden = signup;
    accountArea.hidden = true;
    $("show-signup").classList.toggle("active", signup);
    $("show-login").classList.toggle("active", !signup);
    status("");
  }

  $("show-signup").addEventListener("click", () => showTab("signup"));
  $("show-login").addEventListener("click", () => showTab("login"));

  signupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = signupForm.querySelector("button[type=submit]");
    button.disabled = true;
    status("Account ban raha hai...");
    try {
      const { data, error } = await client.auth.signUp({
        email: $("signup-email").value.trim(),
        password: $("signup-password").value,
        options: { data: { full_name: $("signup-name").value.trim() } }
      });
      if (error) throw error;
      status(data.session
        ? "Account ban gaya aur aap sign in hain."
        : "Account request ho gayi. Email inbox check karein aur confirmation link par tap karein.");
    } catch (error) {
      status(error.message || "Signup nahi ho saka.", true);
    } finally {
      button.disabled = false;
    }
  });

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = loginForm.querySelector("button[type=submit]");
    button.disabled = true;
    status("Sign in ho raha hai...");
    try {
      const { error } = await client.auth.signInWithPassword({
        email: $("login-email").value.trim(),
        password: $("login-password").value
      });
      if (error) throw error;
      status("Sign in successful.");
    } catch (error) {
      status(error.message || "Sign in nahi ho saka.", true);
    } finally {
      button.disabled = false;
    }
  });

  $("reset-password").addEventListener("click", async () => {
    const email = $("login-email").value.trim();
    if (!email) return status("Pehle email address likhein.", true);
    status("Password reset email bheji ja rahi hai...");
    try {
      const { error } = await client.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + window.location.pathname
      });
      if (error) throw error;
      status("Agar email account mojood hai to reset link bhej diya gaya hai. Inbox check karein.");
    } catch (error) {
      status(error.message || "Reset email nahi bheji ja saki.", true);
    }
  });

  $("sign-out").addEventListener("click", async () => {
    const { error } = await client.auth.signOut();
    if (error) return status(error.message, true);
    status("Aap sign out ho gaye.");
    signupForm.hidden = false;
    loginForm.hidden = true;
    accountArea.hidden = true;
    $("show-signup").classList.add("active");
    $("show-login").classList.remove("active");
  });

  client.auth.onAuthStateChange((_event, session) => {
    if (session?.user) {
      signupForm.hidden = true;
      loginForm.hidden = true;
      accountArea.hidden = false;
      $("account-email").textContent = session.user.email || "";
      $("show-signup").classList.remove("active");
      $("show-login").classList.remove("active");
    }
  });

  client.auth.getSession().then(({ data }) => {
    if (data.session?.user) {
      signupForm.hidden = true;
      loginForm.hidden = true;
      accountArea.hidden = false;
      $("account-email").textContent = data.session.user.email || "";
    }
  });
})();
