// Public Supabase project settings. Never put a service_role/secret key in this file.
window.BK_SUPABASE_URL = "https://xkbdxorssrmuxbrbfljd.supabase.co";
window.BK_SUPABASE_ANON_KEY = "sb_publishable_qP3N0WKucQgJm_VKbZAjQQ_8CjzJ_9J";
