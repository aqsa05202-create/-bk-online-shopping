/* B_K ONLINE SHOPPING Supabase browser configuration.
   This file contains only the public publishable key.
   NEVER put a Supabase secret/service_role key in website files. */
window.BK_SUPABASE_URL = 'https://xkbdxorssrmuxbrbfljd.supabase.co';
window.BK_SUPABASE_ANON_KEY = 'sb_publishable_qP3N0WKucQgJm_VKbZAjQQ_8CjzJ_9J';
