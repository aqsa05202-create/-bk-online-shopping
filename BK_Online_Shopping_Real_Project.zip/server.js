require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("data.sqlite");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('owner','seller','customer')),
 status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 seller_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 description TEXT DEFAULT '',
 price REAL NOT NULL,
 currency TEXT NOT NULL DEFAULT 'PKR',
 stock INTEGER NOT NULL DEFAULT 0,
 image_url TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(seller_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL,
 quantity INTEGER NOT NULL,
 unit_price REAL NOT NULL,
 currency TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES users(id),
 FOREIGN KEY(product_id) REFERENCES products(id)
);
`);

const ownerEmail = (process.env.OWNER_EMAIL || "").toLowerCase();
const ownerPassword = process.env.OWNER_PASSWORD || "";
if (ownerEmail && ownerPassword) {
  const exists = db.prepare("SELECT id FROM users WHERE email=?").get(ownerEmail);
  if (!exists) {
    const hash = bcrypt.hashSync(ownerPassword, 12);
    db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'owner')")
      .run("B_K Owner", ownerEmail, hash);
  }
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:false}));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-this",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly:true, sameSite:"lax", secure: process.env.NODE_ENV === "production", maxAge: 1000*60*60*8 }
}));
app.use(express.static(path.join(__dirname,"public")));

const userView = u => ({id:u.id,name:u.name,email:u.email,role:u.role,status:u.status});
function auth(req,res,next){ if(!req.session.user) return res.status(401).json({error:"Login required"}); next(); }
function role(...roles){ return (req,res,next)=>{ if(!req.session.user || !roles.includes(req.session.user.role)) return res.status(403).json({error:"Not allowed"}); next(); }; }

app.post("/api/register", (req,res)=>{
  const {name,email,password,role:requestedRole} = req.body;
  if(!name || !email || !password || password.length < 10) return res.status(400).json({error:"Name, email aur kam az kam 10-character password zaroori hain."});
  if(!["seller","customer"].includes(requestedRole)) return res.status(400).json({error:"Invalid account type"});
  try {
    const hash=bcrypt.hashSync(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password_hash,role,status) VALUES(?,?,?,?,?)")
      .run(name.trim(),email.trim().toLowerCase(),hash,requestedRole,requestedRole==="seller"?"pending":"active");
    const user=db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
    if(user.role==="customer"){ req.session.user=userView(user); return res.json({user:req.session.user}); }
    res.json({message:"Seller application submitted. Owner approval is required."});
  } catch(e){ res.status(409).json({error:"This email may already be registered."}); }
});

app.post("/api/login",(req,res)=>{
  const email=String(req.body.email||"").toLowerCase().trim(), password=String(req.body.password||"");
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!user || !bcrypt.compareSync(password,user.password_hash)) return res.status(401).json({error:"Email ya password ghalat hai."});
  if(user.status!=="active") return res.status(403).json({error:"Account abhi active nahi. Seller approval ka intezar karein."});
  req.session.user=userView(user); res.json({user:req.session.user});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({user:req.session.user||null}));

app.get("/api/products",(req,res)=>{
  const rows=db.prepare(`SELECT p.id,p.name,p.description,p.price,p.currency,p.stock,p.image_url,u.name AS seller_name
    FROM products p JOIN users u ON u.id=p.seller_id WHERE p.status='approved' ORDER BY p.id DESC`).all();
  res.json(rows);
});
app.post("/api/products",auth,role("seller"),(req,res)=>{
  const {name,description,price,currency,stock,image_url}=req.body;
  const amount=Number(price), qty=Number(stock);
  if(!name || !Number.isFinite(amount) || amount<=0 || !Number.isInteger(qty) || qty<0 || !["PKR","USD"].includes(currency))
    return res.status(400).json({error:"Product details check karein. Currency PKR ya USD honi chahiye."});
  const info=db.prepare("INSERT INTO products(seller_id,name,description,price,currency,stock,image_url) VALUES(?,?,?,?,?,?,?)")
    .run(req.session.user.id,name,description||"",amount,currency,qty,image_url||"");
  res.json({id:info.lastInsertRowid,message:"Product owner approval ke liye submit ho gaya."});
});
app.get("/api/seller/products",auth,role("seller"),(req,res)=>{
  res.json(db.prepare("SELECT * FROM products WHERE seller_id=? ORDER BY id DESC").all(req.session.user.id));
});
app.get("/api/admin/summary",auth,role("owner"),(req,res)=>{
  res.json({
    users:db.prepare("SELECT COUNT(*) n FROM users").get().n,
    pendingSellers:db.prepare("SELECT COUNT(*) n FROM users WHERE role='seller' AND status='pending'").get().n,
    pendingProducts:db.prepare("SELECT COUNT(*) n FROM products WHERE status='pending'").get().n,
    orders:db.prepare("SELECT COUNT(*) n FROM orders").get().n
  });
});
app.get("/api/admin/sellers",auth,role("owner"),(req,res)=>{
  res.json(db.prepare("SELECT id,name,email,status,created_at FROM users WHERE role='seller' ORDER BY id DESC").all());
});
app.post("/api/admin/sellers/:id/approve",auth,role("owner"),(req,res)=>{
  db.prepare("UPDATE users SET status='active' WHERE id=? AND role='seller'").run(req.params.id); res.json({ok:true});
});
app.post("/api/admin/sellers/:id/reject",auth,role("owner"),(req,res)=>{
  db.prepare("UPDATE users SET status='rejected' WHERE id=? AND role='seller'").run(req.params.id); res.json({ok:true});
});
app.get("/api/admin/products",auth,role("owner"),(req,res)=>{
  res.json(db.prepare("SELECT p.*,u.name seller_name FROM products p JOIN users u ON u.id=p.seller_id ORDER BY p.id DESC").all());
});
app.post("/api/admin/products/:id/approve",auth,role("owner"),(req,res)=>{
  db.prepare("UPDATE products SET status='approved' WHERE id=?").run(req.params.id); res.json({ok:true});
});
app.post("/api/orders",auth,role("customer"),(req,res)=>{
  const product=db.prepare("SELECT * FROM products WHERE id=? AND status='approved'").get(Number(req.body.product_id));
  const qty=Number(req.body.quantity);
  if(!product || !Number.isInteger(qty) || qty<1 || qty>product.stock) return res.status(400).json({error:"Product ya stock available nahi."});
  const info=db.prepare("INSERT INTO orders(customer_id,product_id,quantity,unit_price,currency) VALUES(?,?,?,?,?)")
    .run(req.session.user.id,product.id,qty,product.price,product.currency);
  db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(qty,product.id);
  res.json({orderId:info.lastInsertRowid,message:"Order request created. Payment abhi manual/offline setup hai."});
});
app.get("/api/admin/orders",auth,role("owner"),(req,res)=>{
  res.json(db.prepare(`SELECT o.*,u.name customer,p.name product FROM orders o
    JOIN users u ON u.id=o.customer_id JOIN products p ON p.id=o.product_id ORDER BY o.id DESC`).all());
});
app.patch("/api/admin/orders/:id",auth,role("owner"),(req,res)=>{
  const allowed=["pending","confirmed","shipped","delivered","cancelled"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id); res.json({ok:true});
});

const port=Number(process.env.PORT)||3000;
app.listen(port,()=>console.log(`B_K ONLINE SHOPPING running on http://localhost:${port}`));
